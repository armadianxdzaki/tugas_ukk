<?php
class M_Dashboard extends CI_Model{
	
}